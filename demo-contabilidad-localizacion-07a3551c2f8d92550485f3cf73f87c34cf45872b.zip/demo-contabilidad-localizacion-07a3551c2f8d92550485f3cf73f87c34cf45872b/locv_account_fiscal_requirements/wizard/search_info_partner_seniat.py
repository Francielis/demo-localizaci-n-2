# coding: utf-8
##############################################################################

from odoo import  models, fields

class SearchInfoPartnerSeniat(models.TransientModel):

    _name = "search.info.partner.seniat"
