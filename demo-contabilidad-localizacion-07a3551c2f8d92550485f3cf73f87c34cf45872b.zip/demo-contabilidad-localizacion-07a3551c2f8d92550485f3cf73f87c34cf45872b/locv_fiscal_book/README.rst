Fiscal Report For Venezuela
===========================


Fiscal Book
===============================================================================
Build all Fiscal Reports for Law in Venezuela.
Add 2 new columns because of:

Según Articulo 77 del Reglamento de la Ley del IVA No.5.363 del 12 de Julio de
1999.
Parágrafo Segundo: El registro de las operaciones contenidas en el reporte
global diario generado por las máquinas fiscales, se reflejarán en el Libro
de Ventas del mismo modo que se establece respecto de los comprobantes que
se emiten a no contibuyentes, indicando el número de registro de la máquina.

.. note::
    El libro de ventas no contempla la sección de Ventas por cuenta de
    Terceros.