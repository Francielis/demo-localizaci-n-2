# coding: utf-8
###########################################################################

##############################################################################
{
    "name": "Localizacion Grupo",
    "version": "1.0",
    "author": "Localizacion Venezolana",
    "license": "AGPL-3",
    "category": "grupos",
    #"website": "",
    "colaborador":"Maria Carreno",
    'depends': ['base'],

    'demo': [
    ],
    "data": [
        'security/security.xml',
        'security/ir.model.access.csv',
    ],
    'test': [

    ],
    "installable": True,
    'application': True,
}
