# -*- coding: utf-8 -*-

#from . import res_currency_rate_inherit
from . import wizard_retention_islr
