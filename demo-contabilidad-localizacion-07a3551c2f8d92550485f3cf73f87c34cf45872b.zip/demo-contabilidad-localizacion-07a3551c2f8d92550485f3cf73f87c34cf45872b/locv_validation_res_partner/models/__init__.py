from . import docum_ident_res_partner
from . import res_partner_people_type
