from . import rif_res_company_validation
from . import res_partner_validation
