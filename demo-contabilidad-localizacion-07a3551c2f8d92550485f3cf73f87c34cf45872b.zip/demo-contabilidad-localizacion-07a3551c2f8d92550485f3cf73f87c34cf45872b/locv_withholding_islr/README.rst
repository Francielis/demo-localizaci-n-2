Automatically Calculation Income Withholding
============================================


 - Generate the voucher of income withholding to validate the invoice.
 - Generate the report of voucher of income withholding.
 - Generate the file .xml required by the Venezuelan laws, for agent of income
   withholding specials.
 - Generate view for load the concepts of wittholding whith their rates.
 - Generate view for visualize the income withholding for suppilers and
   customers.
 - Load data of the 86 concepts of wittholdings whith their rates.
 - Send an email to supplier with approved withholdings, if not opt_out in the
   partner

if you want be able to propose withholding concepts from sales and purchases
you must install extra module @section{l10n_ve_sale_purchase}.
