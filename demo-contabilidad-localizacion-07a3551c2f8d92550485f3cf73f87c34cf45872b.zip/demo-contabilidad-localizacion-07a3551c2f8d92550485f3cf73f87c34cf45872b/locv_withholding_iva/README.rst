Management withholding vat based in the Venezuelan tax laws
===========================================================


Management withholding vat based in the Venezuelan tax laws.

 - Create from invoice voucher withholding vat, to validate invoice.
 - Generate new tag in the view of partner for  add information basic of
   withholdings vat.
 - Generate file .txt required by Venezuelan law, based in the withholdings vat
   made during period defined for users.
 - Generate voucher of withholding vat based in the Venezuelan tax laws.

**Recommendations:**

 - If you want to be able to print the vat withholding report correctly, It is
   recomended to define the size of the logo of the company in 886 x 236
   pixeles.